
export async function onRequestPost(context) {
  const { request, env } = context;
  try {
    const data = await request.json();
    const { name, phone, qty, product, city, channel } = data;

    const text = `🔥 Новый заказ!\nТовар: ${product}\nГород: ${city}\nКлиент: ${name} ${phone}\nКол-во: ${qty}\nКанал: ${channel}\nВремя: ${new Date().toLocaleString('ru-RU')}`;

    // Telegram
    if (env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_CHAT_ID) {
      await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text, parse_mode: 'HTML' })
      });
    }

    // MAX Messenger
    if (env.MAX_BOT_TOKEN && env.MAX_CHAT_ID) {
      await fetch(`https://platform-api.max.ru/bot/${env.MAX_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': env.MAX_BOT_TOKEN },
        body: JSON.stringify({ chat_id: env.MAX_CHAT_ID, text })
      }).catch(()=>{});
    }

    return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500 });
  }
}
